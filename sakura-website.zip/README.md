# 🌸 Sakura Garden Website

Project website sederhana bertema bunga sakura.

## Fitur
- Landing page menarik
- Navigasi sederhana
- Galeri gambar bunga sakura
- Desain responsif

## Cara Menjalankan
1. Download project
2. Buka file `index.html` di browser

## Author
Mortification Records
